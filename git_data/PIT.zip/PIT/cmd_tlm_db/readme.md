This is where command and telemetry CSV files copied from the flight unit are stored
